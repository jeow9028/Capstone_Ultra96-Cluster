	#!/bin/bash
#echo -n "Network Script - Enter Corresponding number to list IP"
read CHOICE

echo -n "Choices 1 & 2"

case CHOICE in
	
	PATTERN_1)
    	echo -n "All"
	sudo arp-scan --interface=wlp2s0 --localnet
    	;;
	PATTERN_2)
	echo - "Capstone"
	arp-scan --interface=wlp2s0 --localnet | grep "REAL"
	;;


esac

#Bash Script for Interface
sudo arp-scan --interface=wlp2s0 --localnet

#Bash Scripting only Xilinx captstone devices (Uncomment)
#arp-scan --interface=wlp2s0 --localnet | grep "REAL"
