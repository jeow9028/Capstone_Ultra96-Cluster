# **********************
#!/usr/bin/python
# ports open: [ -- 19132 (UDP) ]
#             [  -- 25564 (TCP)]   
# **********************

import socket #import socket module

s = socket.socket() #create a socket object

host = '10.0.0.115' #Host i.p
port = 19132 #Reserve a port for your service

s.connect((host,port))
print s.recv(1024)
s.close