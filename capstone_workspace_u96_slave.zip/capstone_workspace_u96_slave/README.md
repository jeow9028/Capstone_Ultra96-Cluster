This Document must be editted to display highlight overview and features of each device

*****************************
Project: ClusterZ
Authro: Jean-Christophe Owens
Xilinx SERG 2020 
FAE Capstone
****************************

| Device 1 | Master u96-v2 |

--------------------------------

| Device 2 \ Slave 1 - u96-v2 |

| Device 3 \ Slave 2 - u96-v2 |

| Device 4 \ Slave 3 - u96-v2 |

*OPTIONAL TASK*

| Device 5 \ Slave 4 - pynq-z2 |

--------------------------------

1) Create Kubernetes architecture with corresponding nodes (master | slave) 
2) Create overlays for each device in Vivado
3) Generate .tcl & .bit for each module
4) Upload to the pynq overlay project
5) Write in overlay to the master device 
6) Distribute bit files to according device via master
7) Showcase that an external device such as (Pynq-Z2) can be attached from pynq flow)
8) Run demo folder
9) Have a nice day :) 


